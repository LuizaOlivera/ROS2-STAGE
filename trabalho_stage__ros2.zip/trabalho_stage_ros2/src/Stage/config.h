#ifndef _CONFIG_H
#define _CONFIG_H

#define PROJECT "Stage"
#define VERSION "4.3.0"
#define FULL_VERSION 4-3-0
#define APIVERSION "4.3"
#define INSTALL_PREFIX "/home/vboxuser/Downloads/trabalho_stage_ros2/install/stage"
#define PLUGIN_PATH "/home/vboxuser/Downloads/trabalho_stage_ros2/install/stage/lib/Stage-4.3"

/* #undef BUILD_GUI */

#endif
